clear; clc; clf

%% Initialize Global and Local Variables
global new_verts fverts xR yR xL yL
x=0; y=0;

arena_size=75; %bigger arena makes things more interesting.
draw_robot() % show robot for the first time (no arguments)
axis([-arena_size arena_size -arena_size arena_size]);  % create dummy arena
set(gca,'color','k');
axis square
set(gca,'Visible','on');

t       = 0;
dt      = 0.1;
tstop   = 50;
tvec    = t:dt:tstop;

% food target location
allowedLocations = 'all';
switch allowedLocations
    case 'all'
        maketgt = @() [150*rand(1,2)-[75 75]];
    case 'NE'
        maketgt = @() [75*rand(1,2)];
end

tgt = maketgt();

%Make Food
f_center    = tgt;
f_width     = 5;
food        = rectangle('Position',[f_center(1)-f_width(1)/2,f_center(2)-f_width(1)/2,f_width(1),f_width(1)],'Curvature',[0.5,0.5],'EdgeColor','w');
set(food,'Position',[f_center(1)-f_width(1)/2,f_center(2)-f_width(1)/2,f_width(1),f_width(1)],'Curvature',[0.5,0.5]);

heading_angle=0;

% Identify the X and Y coordinate of the R and L sensor from the robot description
xR = 10;
yR = -5;
xL = 10;
yL = 5;

% Compute the initial magnitude of the sensor info
sensorMag = @(tgt,loc) sqrt((tgt(1)-loc(1))^2+(tgt(2)-loc(2))^2);
sensorL = 1/sensorMag(tgt,[xL yL]);
sensorR = 1/sensorMag(tgt,[xR yR]);

% Compute the angle of the bug
sensorAng = @(tgt,loc1,loc2) ...
    atan( (tgt(2)-(loc1(2)+loc2(2))/2) / (tgt(1)-(loc1(1)+loc2(1))/2) );

heading_angle = sensorAng(tgt,[xL yL],[xR yR]);

if (tgt(1)<((xL+xR)/2) && tgt(2)>((yL+yR)/2)) || ... % quadrant II
        (tgt(1)<((xL+xR)/2) && tgt(2)<((yL+yR)/2))   % quadrant III
    heading_angle = pi+heading_angle;
end

draw_robot(x,y,heading_angle);

personalityType = 'aggressor';
v = zeros(1,2); % initial membrane voltage

t1 = zeros(size(tvec));
t2 = zeros(size(tvec));

delta_angle=0;

sumexpR = zeros(size(tvec));
sumexpL = zeros(size(tvec));

for k=1:length(tvec)
    [motorL,motorR,v] = brain_avoid(sensorL,sensorR,dt,v);
    fprintf(sprintf('Vm=[%2.2g %2.2g] \n',v(1),v(2)))
    if any([motorL motorR])
        fprintf(sprintf('motorL=%2.2g motorR=%2.2g \n',motorL,motorR))
    end
    
    if delta_angle
        fprintf(sprintf('delta angle=%2.2g \n',delta_angle))
    end
    
    switch personalityType
        case 'coward'
            % relate the left and right velocities to motor outputs
            vel_left  = motorL;
            vel_right = motorR;
            
            % update heading angle and x,y location of robot
            if vel_right > vel_left
                delta_angle = pi/2 + atan( (vel_right-vel_left) / 10 );
            elseif vel_left > vel_right
                delta_angle = -atan( (vel_left-vel_right) / 10 );
            else delta_angle = 0;
            end
            heading_angle = heading_angle + delta_angle;
            
            x = x + min(vel_left,vel_right)*cos(heading_angle)*dt; %change x direction
            y = y + min(vel_left,vel_right)*sin(heading_angle)*dt; %change y direction
            
        case 'aggressor'
            t1(k) = motorL;
            t2(k) = motorR;
            tau = 25;
            amp = 2;
            
            % vector of summed exponentials to "smooth out" 1's and 0's
            expvec = amp*exp(-[1:length(tvec)]/tau);
            
            % if motorL fires
            if t1(k) == 1
                % scalar to potentially exaggerate difference between sensors
                S = (1 + (sensorL-sensorR)/sensorL);
                if sensorL > sensorR
                    % increase effect of firing
                    expvec = S*amp*exp(-[1:length(tvec)]/(S*tau));
                elseif sensorR > sensorL
                    % decrease affect of firing
                    expvec = (2-S)*amp*exp(-[1:length(tvec)]/((2-S)*tau));
                end
                sumexpL(k:end) = sumexpL(k:end)+expvec(1:(length(tvec)-k+1));
            end
            
            % if motorR fires
            if t2(k) == 1
                % scalar to potentially exaggerate difference between sensors
                S = (1 + (sensorR-sensorL)/sensorR);
                if sensorR > sensorL
                    % increase effect of firing
                    expvec = S*amp*exp(-[1:length(tvec)]/(S*tau));
                elseif sensorL < sensorR
                    % decrease effect of firing
                    expvec = (2-S)*amp*exp(-[1:length(tvec)]/((2-S)*tau));
                end
                sumexpR(k:end) = sumexpR(k:end)+expvec(1:(length(tvec)-k+1));
            end
            
            % set left and right velocities based on sum of exponentials
            vel_right = sumexpR(k);
            vel_left  = sumexpL(k);
            fprintf(sprintf('Velocity: L=%1.2g, R=%1.2g \n',vel_left,vel_right))
            
            % change heading angle accordingly
            if vel_left > vel_right
                % turn right
                fprintf(sprintf('Heading Angle: %2.2g ',heading_angle))
                delta_angle = -pi/2 + atan(10/(vel_left-vel_right));
                heading_angle = heading_angle + delta_angle;
                fprintf(sprintf(' -> %2.2g (R)\n',heading_angle))
            elseif vel_right > vel_left
                % turn left
                fprintf(sprintf('Heading Angle: %2.2g ',heading_angle))
                delta_angle = atan( (vel_right-vel_left)/10 );
                heading_angle = heading_angle + delta_angle;
                fprintf(sprintf(' -> %2.2g (L)\n',heading_angle))
%                 keyboard
            end
            
            if heading_angle > 2*pi
                heading_angle = heading_angle-2*pi;
            elseif heading_angle < 0
                heading_angle = heading_angle+2*pi;
            end
            
            scale = 10;
            x = x + scale*min(vel_left,vel_right)*cos(heading_angle)*dt; %change x direction
            y = y + scale*min(vel_left,vel_right)*sin(heading_angle)*dt; %change y direction
            
    end
    
    
    % Identify the X and Y coordinate of the R and L sensor from the
    %   robot description
    xR = x+5*sqrt(5)*cos(atan(-5/10)+heading_angle);
    yR = y+5*sqrt(5)*sin(atan(-5/10)+heading_angle);
    xL = x+5*sqrt(5)*cos(atan(5/10)+heading_angle);
    yL = y+5*sqrt(5)*sin(atan(5/10)+heading_angle);
    
    % Compute the magnitude of the sensor info
    scalar = 1/1e1;
    sensorL = sensorMag(tgt,[xL yL])*scalar;
    sensorR = sensorMag(tgt,[xR yR])*scalar;
    
    m = (max(sensorL,sensorR)-min(sensorL,sensorR))/max(sensorL,sensorR);
    if sensorL > sensorR
        sensorL = (1+m) * sensorL;
        sensorR = (1-m) * sensorR;
    elseif sensorR > sensorL
        sensorL = (1-m) * sensorL;
        sensorR = (1+m) * sensorR;
    end
    
    fprintf(sprintf('Sensor: L=%2.2g, R=%2.2g \n',sensorL,sensorR))
    
    % have arena wrap on itself
    if x>arena_size; x=-arena_size; end
    if y>arena_size; y=-arena_size; end
    if x<-arena_size; x=arena_size; end
    if y<-arena_size; y=arena_size; end
    
    % heading_angle = pi/2;
    draw_robot(x,y, heading_angle);
    drawnow
    
    DL = sqrt((x-tgt(1))^2+(y-tgt(2))^2);
    if DL < 10
        tgt = maketgt();
        f_center = tgt;
        set(food,'Position',[f_center(1)-f_width(1)/2,f_center(2)-f_width(1)/2,f_width(1),f_width(1)],'Curvature',[0.5,0.5]);
    end
    fprintf('\n')
%     if mod(k,25) == 0; keyboard; end
end

%% spiking
% figure(2); hold on
% plot(tvec,sumexpR,'k-')
% plot(tvec,sumexpL,'k--')
% legend('R','L')